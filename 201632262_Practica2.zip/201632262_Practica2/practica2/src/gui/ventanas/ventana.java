
package gui.ventanas;

import java.awt.Color;
    import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import javax.swing.JButton;


public class ventana extends javax.swing.JFrame {
    
  
     JButton[][] CUADRO;
     int filas = 0;

  
    
    public ventana() {
        initComponents();
      
       
                    

    }

 
     
       
       
   
   
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        botonesjPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        tamaniojTextField1 = new javax.swing.JTextField();
        comenzarjButton1 = new javax.swing.JButton();
        salirjButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout botonesjPanel1Layout = new javax.swing.GroupLayout(botonesjPanel1);
        botonesjPanel1.setLayout(botonesjPanel1Layout);
        botonesjPanel1Layout.setHorizontalGroup(
            botonesjPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 470, Short.MAX_VALUE)
        );
        botonesjPanel1Layout.setVerticalGroup(
            botonesjPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 145, Short.MAX_VALUE)
        );

        jLabel1.setText("Introdusca #");

        tamaniojTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tamaniojTextField1ActionPerformed(evt);
            }
        });

        comenzarjButton1.setText("Comenzar");
        comenzarjButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comenzarjButton1ActionPerformed(evt);
            }
        });

        salirjButton2.setText("Salir");
        salirjButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salirjButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(botonesjPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(1, 1, 1)
                        .addComponent(tamaniojTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(comenzarjButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(salirjButton2)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(tamaniojTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comenzarjButton1)
                    .addComponent(salirjButton2))
                .addGap(18, 18, 18)
                .addComponent(botonesjPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tamaniojTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tamaniojTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tamaniojTextField1ActionPerformed

    
    private void comenzarjButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comenzarjButton1ActionPerformed

         
        
    
        filas= Integer.parseInt(tamaniojTextField1.getText());
       
        
   
    
        
        
        CUADRO = new JButton[filas][filas];
        botonesjPanel1.setLocation(filas, filas);

        botonesjPanel1.setLayout(new GridLayout(filas,filas));
        
       int x=10;
       int y=10;
       
       for (int i = 0; i < filas; i++) {
           for (int j = 0; j < filas; j++) {
               
               CUADRO[i][j]=new JButton ();
                CUADRO[i][j].setToolTipText("¿selecciona?");
               if(i%2==0){
                    if(j%2==0) CUADRO[i][j].setBackground(Color.white);
                    else CUADRO[i][j].setBackground(Color.black);
                }
                else{
                    if(j%2!=0) CUADRO[i][j].setBackground(Color.white);
                    else CUADRO[i][j].setBackground(Color.black);
                }
               
                CUADRO[i][j].setBounds(x, y, 100, 100);
               
                
               botonesjPanel1.add(CUADRO[i][j]);
               
               
               y+=100;
               
           }
          x+=100;
          y=10;
       }
                    

       
    }//GEN-LAST:event_comenzarjButton1ActionPerformed
     
    
    
    private void salirjButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salirjButton2ActionPerformed
    System.exit(0);
            // TODO add your handling code here:
    }//GEN-LAST:event_salirjButton2ActionPerformed
       public void metodos( ActionEvent e){
           if (e.getSource()==CUADRO[0][0]) {
               for (int j = 1; j < filas; j++) {
                   CUADRO[0][j].setBackground(Color.red);
                   
                   
               }
               
           }
        //Se asigna el color de fondo azul
        setBackground(Color.BLUE);
        //Se asigna un color de letra color blanco
        setForeground(Color.WHITE);
       }
     
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ventana().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel botonesjPanel1;
    private javax.swing.JButton comenzarjButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton salirjButton2;
    private javax.swing.JTextField tamaniojTextField1;
    // End of variables declaration//GEN-END:variables
}
