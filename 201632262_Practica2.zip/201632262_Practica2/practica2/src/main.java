
import gui.ventanas.ventana;


public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ventana ventanaPrincipal =new ventana();
        ventanaPrincipal.setVisible(true);
    }
    
}
